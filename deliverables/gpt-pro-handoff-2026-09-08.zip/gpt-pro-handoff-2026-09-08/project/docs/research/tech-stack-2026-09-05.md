# 育てる地図：技術スタックとOSSの選定記録

調査日：2026年9月5日
対象：[要件定義と技術設計 v4](../spec/requirements.md)
位置付け：公式資料、ソースコード、公開デモに基づく推奨案。製品への組込みと実機検証はこれから行う。

## 現行方針との違い

本書は調査時点の比較記録。現在は[実装仕様書](../spec/implementation.md)と[地図の要件](../requirements/grow-map.md)を優先する。

| 項目 | 後続文書での方針 |
|---|---|
| 地図 | Mapbox Standardを基盤とし、PLATEAUは採用しない |
| DB・実行環境 | PostgreSQL＋PostGIS、Node.js＋Bun。SupabaseとDockerは必須構成から外した |
| プラグイン | 端末側で実行・API通信する |
| 完成段階 | Macの仮想端末で再生入力を使うデモ。スマホ実機と背景記録は追加段階 |

スマホ記録・クラウド配信は候補として参照する。実機へ進む際は[位置情報SDKの選定メモ](location-sdk-2026-09-05.md)を使う。

## 調査時点の推奨案

**推奨は、Next.jsとReactを中心に、mapcnの完成した画面ブロックを取り込み、MapLibre GL JSとdeck.glで地図を拡張する構成である。**
検索一覧、ピン、地図移動、詳細表示は既存実装を使い、下部パネル、レイヤー管理、範囲指定にもOSSを組み合わせる。
開発の中心を、GPTとの会話で場所の意味を見つけること、互いの地図の対応を見せること、Codexで地図機能を増やすことに置ける。

完成したGISアプリを土台にする場合の第一候補はGeoLibreとする。
地図、解析、プラグインをまとめて流用できる点が強い。
今回の推奨は、日々使う個人の地図としての画面を作りやすいという設計判断であり、両案の実装時間を測定した結果ではない。
端末は、スマホでの日常利用とPCでの比較を想定して評価した。
チームの得意なフレームワークと、記録機能を一つのアプリへ統合する時期は未確定である。

## 1. 構成案と各技術の役割

| 領域 | 推奨する技術 | この製品での役割 |
|---|---|---|
| Web画面と通常API | Next.js 16系、React 19系、TypeScript | 地図、会話、比較、共有、機能作成を接続する |
| 地図画面の土台 | mapcnのStore Locatorブロック | 検索一覧とピンの連動、地点選択、カメラ移動、詳細表示を流用する |
| 操作パネル | Tailwind CSS 4系、shadcn/ui、Base UI Drawer | スマホの下部パネルとPCの操作欄を構成する |
| 地図描画 | MapLibre GL JS 6系 | 背景地図、道路、建物、通常の点と線、地図操作を担当する |
| 高度な地図表現 | deck.gl 9系 | 多数の軌跡、集約表示、用途の対応線、3D Tilesを扱う |
| レイヤー管理 | maplibre-gl-layer-control | 表示切替、不透明度、スタイル編集を流用する |
| 図形の入力 | maplibre-gl-terradraw | 場所や共有範囲を囲む操作、点や線の編集に使う |
| 背景地図 | OpenFreeMap、Maputnik | 配信済みの地図とスタイルを使い、配色やラベルを調整する |
| 独自の地理データ | GeoJSON、MVT、PMTiles、必要に応じて3D Tiles | 公開地理データと個人の記録を、それぞれの更新頻度に合う形式で配信する |
| 保存と検索 | SupabaseのPostgres、PostGIS、Auth、Storage | 場所、経路、会話、共有関係、画像を保持する。意味検索にはpgvectorを加える |
| 対話UIとGPT | AI Elements、AI SDKのOpenAI provider、Responses API | メッセージ、入力欄、ストリーミング表示を流用し、場所に紐付く質問と回答を保存する |
| 歩行経路 | openrouteservice、Turf.js | 経由地を通る歩行経路と、距離や範囲との関係を計算する |
| 位置記録の流用 | OwnTracksのHTTP送信 | 既存のスマホアプリから記録を受け取り、Webの個人地図へ反映する |
| Codexの組込み | App Server、Codex SDK、常駐Node.jsサービス | 対話を伴う機能作成と、検証や修復の処理を実行する |
| ジョブと検証環境 | Trigger.dev、E2B | 更新処理の実行と再試行、生成したコードの検証を担当する |

mapcnの確認時点のソースは、React 19、Next.js 16、Tailwind CSS 4、MapLibre GL JS 6.3系を使っている。
古い記事のMapLibre 4系や5系の構成を、そのまま混ぜない。
取り込むコンポーネントのコミットを固定し、依存パッケージの具体的な版は組込み時の動作確認後にlockfileへ固定する。[mapcnのpackage.json](https://github.com/AnmolSaini16/mapcn/blob/d5d287dfdb214c349342f30e407a7c6cf81c4e84/package.json)

配信先は、WebをVercel、DBと認証をSupabase、Codex接続サービスをRailway等の常駐コンテナ、公開タイルをR2へ置く案とする。
Next.jsの通常APIから、長く動く処理へジョブを渡す。
Trigger.devとE2Bを含む接続経路は未検証であり、機能作成からプレビューまで一度通してから確定する。[Trigger.dev](https://trigger.dev/docs/introduction)、[E2B](https://e2b.dev/docs)、[PMTilesのCloudflare配信](https://docs.protomaps.com/deploy/cloudflare)

## 2. 地図UIは、画面と操作の単位で流用する

mapcnの[Store Locatorデモ](https://www.mapcn.dev/view/store-locator)は、左に検索一覧、右に地図を置き、選んだ場所へ移動して詳細を表示する。
ブラウザで一覧選択、詳細の切替、検索による絞込みを確認した。
390 × 844のスマホ相当の幅でも、地図と横から開く一覧を操作できた。
これはブラウザの表示幅を変えた確認であり、スマホ実機の操作性や描画性能の検証ではない。

流用する主なファイルは、`src/registry/blocks/store-locator/`内の`page.tsx`、`components/store-list.tsx`、`components/locator-map.tsx`である。
`data.ts`のサンプル店舗を、自分の場所と共有された場所へ置き換える。
検索は現状ではサンプル配列の文字列検索なので、場所検索APIと個人の記録検索への接続を実装する。[Store Locatorのソース](https://github.com/AnmolSaini16/mapcn/tree/d5d287dfdb214c349342f30e407a7c6cf81c4e84/src/registry/blocks/store-locator)

| 作りたい操作 | 流用するもの | 製品に合わせて実装するもの |
|---|---|---|
| 地図で場所を選び、一覧や詳細を切り替える | Store Locatorの選択状態、ピン、ポップアップ、`flyTo` | 訪問、用途、理由、記憶のカード |
| 場所を見ながらGPTと話す | shadcn/uiのDrawer、AI Elementsの会話と入力欄 | 対象の場所を示す表示、質問の起点、回答後の地図更新 |
| 情報を重ね、濃さを変える | maplibre-gl-layer-control | 持ち主、共有範囲、用途に対応するレイヤーの構成 |
| 共有範囲や寄り道したい範囲を選ぶ | maplibre-gl-terradraw | 範囲と共有権限、推薦条件との接続 |
| 自分と相手の地図を重ねる | MapLibreのレイヤー、mapcnのGeoJSON表示 | 同じ場所の複数の持ち主、用途の共通点と違い |
| 二つの街の対応を見比べる | mapcnのMapを二つ配置し、外部から選択と表示範囲を制御する | 対応する場所の同時選択、独立した中心位置、共通する用途の説明 |
| 情報の有無をスワイプで比較する | maplibre-gl-swipe | 比較するレイヤーの選択と説明。重ね合わせを補う表示として使う |
| 新しい地図機能を追加する | 既存のレイヤー、描画、対話、検証結果の表示 | Codexの実行、版管理、機能の有効化、共有 |

レイヤー管理プラグインには、deck.glなどの独自レイヤーを接続するアダプターの仕組みがある。
MapLibre側とdeck.gl側の表示状態をアプリの同じ状態管理へ結び付ける。[レイヤー管理のAPI](https://github.com/opengeos/maplibre-gl-layer-control#custom-layer-adapters)
図形編集とスワイプ比較も、MapLibre用の既存プラグインを使える。[Terra Drawの操作部品](https://github.com/watergis/maplibre-gl-terradraw)、[スワイプ比較](https://github.com/opengeos/maplibre-gl-swipe)

**スマホの下部パネルは、mapcnの標準画面から変更する。**
現行のshadcn/uiのBase UI Drawerには、段階的な高さを指定する`snapPoints`と、背後の地図を操作できる`modal={false}`がある。
小さく畳む、候補を読む、会話を広げるという状態を構成し、地図の操作ボタンと選択地点がパネルに隠れないよう配置する。
キーボード表示時の高さと、地図のパンとパネルのドラッグの競合は実機で確かめる。[Drawerの公式仕様](https://ui.shadcn.com/docs/components/base/drawer)

「違う場所を同じ用途で使う」という関係は、比較カードと二つの場所の選択状態で表す。
一つの街では同じ地図に双方を表示し、別都市では各地図の中心を別々に保つ。
同じ用途の場所を選んだときに、双方のカードと地点が連動する構成にする。
スワイプやカメラ同期の部品だけでは、この意味の対応は作れないため、ここが独自実装の中心になる。

mapcnは`useMap()`でMapLibreのインスタンスを取得できる。
この経路からdeck.glの`MapboxOverlay`を追加し、地図ラベルと3Dの前後関係が必要な描画にはinterleaved方式を使う。
MapLibreのインスタンスをmapcnで管理する構成に揃え、deck.glのReactサンプルを取り込むときも、その接続に合わせる。[mapcnのAPI](https://www.mapcn.dev/docs/api-reference)、[deck.glのMapLibre連携](https://deck.gl/docs/developer-guide/base-maps/using-with-maplibre)

建物の輪郭と高さによる立体表示にはMapLibreの`fill-extrusion`を使う。
PLATEAUの詳細形状を扱う部分にはdeck.glの`Tile3DLayer`を接続する。
建物が現れる演出は、訪問状態から描画を更新する処理として実装し、表示後は実際の高さへ落ち着かせる。
建物ID、データに含まれる高さ、詳細形状の座標系、対象端末での負荷を検証する。[MapLibreの立体建物例](https://maplibre.org/maplibre-gl-js/docs/examples/display-buildings-in-3d/)、[Tile3DLayer](https://deck.gl/docs/api-reference/geo-layers/tile-3d-layer)

mapcnの`MapRoute`は、渡された座標列を地図へ描画する部品である。
歩ける経路の計算はopenrouteserviceへ接続し、体験上の役割に合う経由地の選択と、その候補の比較をアプリで実装する。[openrouteserviceの経路API](https://giscience.github.io/openrouteservice/api-reference/endpoints/directions/)

## 3. 完成した地図アプリとの比較

| 候補 | 流用できる強み | 今回の位置付けと判断理由 |
|---|---|---|
| mapcn | 検索一覧と地図の連動を含む画面ブロック。Reactとshadcn/uiに接続しやすい | 日常利用の画面の第一候補。下部パネルと意味の比較を自由に組み込める |
| GeoLibre | MapLibreとdeck.glによる地図、レイヤー、スタイル、解析、プラグイン、日本語UI | アプリ全体を流用する場合の第一候補。日常利用の入口を加え、既存のGIS操作をどこへ配置するかが設計課題 |
| kepler.gl | レイヤー、フィルター、時系列、二画面とスワイプ比較、Reactへの埋込みと部品の差替え | 行動データの分析画面に強い。個人の場所や会話を中心とする画面へ適応するには、Redux状態と部品差替えへの接続が必要 |
| TerriaJS / TerriaMap | データカタログ、多形式の読込み、凡例、時系列、分割比較、モバイル用画面、Cesiumによる3D | 公共情報を大量に扱う地図の土台に強い。カタログとWorkbenchのモデルへ個人の場所や用途を対応させる設計が必要 |
| Re:Earth Visualizer | Cesiumによる3D、ストーリー、公開と共有、プラグイン拡張 | 3Dの体験を編集して共有する比重が高い場合に有力。個人の記録と相互比較を、プロジェクトやシーンと結ぶ必要がある |
| MapComponents | MapLibre用のReact部品、レイヤー切替、比較、deck.glとThree.jsへの連携 | 地図部品の別案。確認した構成はMUIと独自Providerを使うため、画面全体のUI基盤も合わせて選ぶ |
| Terrae | 動きのある線やマーカー、比較表示、カメラ追従 | 演出の参考候補。比較部品は背景スタイルの比較が中心で、用途の比較には追加設計が必要 |

GeoLibreの公開デモで、日本語の地図画面、レイヤー欄、プラグインメニューを確認した。
Plugin APIには、地図の取得、独自レイヤーの登録、左右や浮動パネルの追加、設定の保存と復元がある。
これらはCodexが追加機能を作る際の参考になる。
生成コードの検証や、各人の非公開データへ渡す権限は、v4の要件に合わせて別途実装する。[GeoLibreの公開デモ](https://web.geolibre.app/)、[Plugin API](https://github.com/opengeos/GeoLibre/blob/7a7b59d0caf3e68094de16b2a209b0c58b86ffaf/docs/plugin-api.md)

推奨案では、GeoLibreと共有するMapLibre系の独立したプラグインを取り込む。
解析や機能編集を製品の主要な入口にする方針なら、GeoLibre自体を拡張する案へ切り替える価値がある。[GeoLibreの構成](https://github.com/opengeos/GeoLibre)

kepler.glの比較操作と部品差替え、TerriaJSのモバイル用画面は、公式ソースで存在を確認した。
各アプリの改修量やスマホ性能の実測はしていない。[kepler.gl](https://github.com/keplergl/kepler.gl)、[TerriaJS](https://github.com/TerriaJS/terriajs)、[Re:Earth Visualizer](https://github.com/reearth/reearth-visualizer)、[MapComponents](https://github.com/mapcomponents/react-map-components-maplibre)、[Terrae](https://github.com/alamenai/terrae)

## 4. 地図データ、検索、記録は別々に選ぶ

**背景地図はOpenFreeMapを第一候補とする。**
公開配信は登録やAPIキーが不要で、商用利用も認められている。
SLAの保証はないため、対象地域の配信を自分たちで管理したい場合はPMTilesを使う。
日本語ラベルと必要な施設の見え方は、対象地域で確認する。[OpenFreeMapの利用条件](https://openfreemap.org/)

mapcnの標準スタイルはCARTOである。
ソース側のREADMEには、商用利用のライセンスと非商用利用の条件が記載されているため、採用時に`styles`をOpenFreeMapまたは自前のスタイルへ明示的に変更する。
また、現行コンポーネントはMapLibreのWorkerをunpkgから読み込む。
配信を自分たちで管理する場合は、公式手順に従ってWorkerと共有モジュールを同じ配信元へ置く。[mapcnの背景地図に関する記載](https://github.com/AnmolSaini16/mapcn#basemap-terms-of-service)、[Workerの設定](https://www.mapcn.dev/docs/installation)

Maputnikで既存スタイルを調整し、自分と相手の情報が読み取りやすい背景にする。
背景地図、独自の公開データ、個人の記録は別のソースとして扱う。
PMTilesはファイル全体を書き直さずに更新できない形式なので、頻繁に増える個人の記録はPostGISから取得する。
私有の記録を公開タイルへ混ぜず、比較対象者への共有が認められた記録だけを返す。[Maputnik](https://maplibre.org/maputnik/)、[PMTilesの性質](https://docs.protomaps.com/pmtiles/)、[SupabaseのPostGIS](https://supabase.com/docs/guides/database/extensions/postgis)

**地名検索は、今回まだ単独のサービスに確定しない。**
Photonは入力途中の候補検索に対応するOSSで、公開デモAPIもある。
2026年9月5日に、横浜市付近を検索の優先位置として、日本語の三つの施設名を問い合わせた。

| 入力 | 取得できた結果 | 判断 |
|---|---|---|
| 山下公園 | 先頭に山下公園、分類は公園 | この例では目的の場所を取得できた |
| 横浜駅 | 横浜駅根岸道路、分類は道路 | この例では駅を取得できなかった |
| 横浜赤レンガ倉庫 | 先頭に同名の観光施設。自転車貸出拠点等も含まれた | 場所の種類と重複の扱いが必要 |

問合せは`/api/`へ`q`、`limit=3`、`lat=35.45`、`lon=139.64`を指定した。
この三例から日本語検索全体の品質は判断できないが、無調整で採用できるとの判断は避ける。
自分の場所と共有された場所はDB内で検索し、外部の地名検索は別の接続口にする。
Photonを評価候補に残し、対象地域の駅、公園、店名、略称で、正しい施設が候補に入るかを確認して確定する。
公開デモAPIには利用量の制約があるため、継続提供時の自前運用または外部配信先も決める。[Photonの機能と公開APIの条件](https://github.com/komoot/photon)

推薦に使う施設の情報には、検索用の名前と座標に加え、分類、入口、情報源、更新時刻を持たせる。
「落ち着ける」「一人で気持ちを切り替える」といった意味は、本人の回答や共有された経験から蓄積する。
地図タイルに施設名が載っていることと、その施設の用途や情報を検索できることを分けて設計する。

**日常の位置記録には、OwnTracksを流用できる。**
iOSとAndroidのアプリから、自分たちが用意したHTTPSの受信口へ位置情報を送れる。
接続できない場合の送信待ちも既存アプリが扱う。
受信時に端末を本人へ紐付け、計測時刻、精度、重複、欠落を扱う。[OwnTracksのHTTPモード](https://owntracks.org/booklet/tech/http/)

この案には、利用者が記録用アプリを別途設定する手間がある。
地図と記録を一つのアプリへ統合する場合は、ExpoとReact Nativeによる構成を比較する。
mapcnのWeb部品をネイティブの地図UIへそのまま移せるとは限らず、記録部分の連携と地図UIの移植を分けて見積もる。
Expoにもバックグラウンド位置取得の仕組みはあるが、権限、開発ビルド、OSによる終了等の条件がある。
散歩中の画面消灯、再開、電池消費を実機で確かめて記録方式を決める。[Expo Location](https://docs.expo.dev/versions/latest/sdk/location/)

## 5. GPTとCodexをつなぐ設計、および確定前の確認

通常の会話には、AI ElementsのConversation、Message、Prompt Inputを流用する。
AI SDKのOpenAI providerにはResponses APIへの接続がある。
対象の場所、質問、回答、解釈の根拠と修正履歴は、アプリのDBで管理する。[AI Elements](https://elements.ai-sdk.dev/)、[OpenAI providerの実装](https://github.com/vercel/ai/blob/main/packages/openai/src/openai-provider.ts)

Codexによる機能作成は、App Serverと接続するサービスへ渡す。
App Serverのstdio接続を基本に設計し、公開ブラウザから直接接続できる完成済みのクラウドAPIとは扱わない。
認証、作業ディレクトリ、イベントの中継、生成コードの検証環境を用意する。
更新や修復のジョブにはSDKを使い、既存の処理の組合せと、新しい処理や描画の実装を同じ機能管理へ戻す。[Codex App Server](https://learn.chatgpt.com/docs/app-server)

生成する機能の定義には、版、入力、必要な情報源、実行する処理、地図への表示、検証結果を持たせる。
プラグインがmapcn、deck.gl、外部データのどれを使っても、同じ有効化と無効化の操作で扱う。
共有する機能のコードや条件と、その人の非公開データを分離する。
GeoLibreの設定保存とプラグインAPIは、この部分を実装する参考にする。

組込みの最初の確認は、次の五つにまとめる。

| 確認すること | 確かめたい結果 |
|---|---|
| 地図と下部パネルと会話を同時に操作する | スマホ実機で、地図の選択、入力、パネルの開閉が競合しない |
| 自分と相手の場所を表示し、別都市の対応地点を選ぶ | 持ち主と用途の違いが読め、両都市の地図が意図せず同じ中心へ移動しない |
| 対象地域の建物と軌跡を読み込む | 地物IDと高さが対応し、代表的な端末で操作を続けられる |
| 記録から質問、用途の発見、比較まで通す | 行動の記録が本人の説明と結び付き、修正も次の比較へ反映される |
| Codexで情報取得か表示を一つ追加する | 実装、検証、プレビュー、有効化、無効化まで動き、共有時に私有データを持ち出さない |

今回は、mapcn、Terrae、MapComponentsのソースを取得して確認し、GeoLibre、kepler.gl、TerriaJS、Re:Earthの公式資料と関連ソースも比較した。
mapcnとGeoLibreの公開UIを操作し、Photonの公開APIへ三件の検索を実行した。
パッケージを組み合わせたビルド、3Dの性能測定、実機のバックグラウンド記録、歩行経路APIとCodexの一連の接続は未実施である。

| 主な確認対象 | 確認した版またはコミット | コードのライセンス |
|---|---|---|
| mapcn | `d5d287dfdb21` | MIT |
| maplibre-gl-layer-control | `abb258c1c45f` | MIT |
| GeoLibre | `7a7b59d0caf3` | MIT |
| kepler.gl | `d37b8a25e8c4` | MIT |
| TerriaJS | `318baa2ea2ff` | Apache-2.0 |
| Re:Earth Visualizer | `eb88332905df` | Apache-2.0 |
| MapComponentsのreact-maplibreパッケージ | `26ec6870bbd1` | MIT |
| Terrae | `ea9a48034638` | MIT |

表はソース確認時点の記録であり、製品へ取り込んだ版の一覧ではない。
AI ElementsはApache-2.0、OwnTracksはAndroidがEPL-1.0、iOSの主要コードがMITであり、利用対象ごとにライセンスを記録する。[AI Elementsのライセンス](https://github.com/vercel/ai-elements/blob/main/LICENSE)、[OwnTracks Android](https://github.com/owntracks/android/blob/master/LICENSE.md)、[OwnTracks iOS](https://github.com/owntracks/ios/blob/master/LICENSE)
ソースコード、地図データ、配信サービスの条件をそれぞれ確認し、著作権表示と地図の帰属表示を保つ。
PLATEAUは使う地域と年度の配布データを選び、その利用条件と必要な表示を記録する。[PLATEAUのデータ一覧](https://www.mlit.go.jp/plateau/open-data/)

大会への提出前には、重要な既存コード、OSS、データ、第三者ツールと適用ライセンスを書面で開示する。
この選定記録をもとに、実際に取り込んだファイル、版、変更内容を追記して提出用の一覧を作る。[大会の公式ルール](https://codex-student-hack-fes.openai.chatgpt.site/official-rules/)
